//package com.example.mailsendingforusers.repo;
//
//import com.example.mailsendingforusers.entity.Person;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.Optional;
//
///**
// * @author chandrika
// * user
// * @ProjectName mail-sending-for-users
// * @since 28-08-2023
// */
//@Repository
//public interface PersonRepo extends JpaRepository<Person,String> {
//    Optional<Person> findByEmail(String email);
//
//}
//
