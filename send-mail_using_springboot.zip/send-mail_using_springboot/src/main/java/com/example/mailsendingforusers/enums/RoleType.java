package com.example.mailsendingforusers.enums;

/**
 * @author chandrika.g
 * user
 * @ProjectName send-mail_using_springboot
 * @since 21-10-2023
 */
public enum RoleType {
    ADMIN,
    USER

}
