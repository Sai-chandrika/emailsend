//package com.example.mailsendingforusers.entity;
//
//import com.example.mailsendingforusers.dto.BaseEntity;
//import jakarta.persistence.Entity;
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//
///**
// * @author chandrika
// * user
// * @ProjectName send-mail_using_springboot
// * @since 03-10-2023
// */
//@Entity
//@Setter
//@Getter
//@AllArgsConstructor
//@NoArgsConstructor
//public class EmailSend extends BaseEntity {
//    private String from;
//    private String to;
//    private String subject;
//    private String text;
//    private String file;
//
//
//}
